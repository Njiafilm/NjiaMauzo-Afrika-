#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -q -r requirements.txt

export SECRET_KEY="${SECRET_KEY:-$(python3 -c 'import secrets; print(secrets.token_hex(32))')}"
export PASSWORD_SALT="${PASSWORD_SALT:-$(python3 -c 'import secrets; print(secrets.token_hex(16))')}"
export SEED_DEMO_USERS="${SEED_DEMO_USERS:-0}"
export COOKIE_SECURE="${COOKIE_SECURE:-0}"
export PORT="${PORT:-5000}"

# DATABASE_URL examples:
#   (empty)                              → SQLite (default)
#   sqlite:///njiamauzo_v5.3.db
#   postgresql://user:pass@host:5432/db
#   postgres://user:pass@host:5432/db

echo "============================================"
echo "  NjiaMauzo Afrika v5.3 — DUAL DATABASE"
echo "============================================"
echo "  Supports: SQLite (default) + PostgreSQL"
echo "  URL: http://0.0.0.0:${PORT}"
echo "  SEED_DEMO_USERS=${SEED_DEMO_USERS}"
if [ -n "$DATABASE_URL" ]; then
  echo "  DATABASE_URL is set"
else
  echo "  DATABASE_URL not set → using SQLite"
fi
echo "============================================"

python app.py
