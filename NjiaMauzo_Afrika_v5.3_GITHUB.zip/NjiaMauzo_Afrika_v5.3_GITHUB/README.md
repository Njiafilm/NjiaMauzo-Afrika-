# NjiaMauzo Afrika v5.3

**Agricultural marketplace & market intelligence for East Africa.**

Supports **SQLite** (default) and **PostgreSQL** via environment variable.

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Flask](https://img.shields.io/badge/Flask-3.x-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

## Features

- Crop price intelligence across East Africa
- Profit / transport cost calculator
- Marketplace (buy & sell listings)
- Simple AI search & chat
- Dual database support (SQLite + PostgreSQL)
- Performance optimizations (indexes, WAL, caching)

## Quick Start

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/NjiaMauzo-Afrika.git
cd NjiaMauzo-Afrika

# 2. Setup environment
cp .env.example .env
# Edit .env if needed

# 3. Run
chmod +x start.sh
./start.sh
```

Open: http://127.0.0.1:5000

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | SQLite file | `sqlite:///...` or `postgresql://user:pass@host:5432/db` |
| `SECRET_KEY` | auto | Flask session secret |
| `PASSWORD_SALT` | auto | Password hashing salt |
| `SEED_DEMO_USERS` | `0` | Set `1` only for demos |
| `COOKIE_SECURE` | `0` | Set `1` behind HTTPS |
| `PORT` | `5000` | Server port |

## Database

| Mode | How |
|------|-----|
| **SQLite** (default) | Leave `DATABASE_URL` empty |
| **PostgreSQL** | `DATABASE_URL=postgresql://user:pass@host:5432/dbname` |

Health check: `GET /api/health`

## Demo Accounts

Only available when `SEED_DEMO_USERS=1`:

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@njiamauzo.demo | admin123 |
| Seller | juma@njiamauzo.demo | seller123 |
| Buyer | amina@njiamauzo.demo | buyer123 |

**Do not use these in production.**

## Project Structure

```
├── app.py
├── requirements.txt
├── start.sh
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

## Deploy

Works well on:

- [Render](https://render.com)
- [Railway](https://railway.app)
- [Fly.io](https://fly.io)
- Any VPS with Python

## License

MIT
