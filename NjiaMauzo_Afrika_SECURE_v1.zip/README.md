# NjiaMauzo Afrika — Secure

## Render
Build Command:
pip install -r requirements.txt

Start Command:
gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --timeout 120

## First admin login
Email: value of ADMIN_EMAIL (default admin@njiamauzo.africa)
Temporary password: 0000

Immediately change the password after first login.

## Important
For production, configure DATABASE_URL with Render PostgreSQL. SQLite on an ephemeral filesystem can lose data after restarts/redeploys.

Payment numbers are supplied by backend environment variables and are not hardcoded in index.html.
