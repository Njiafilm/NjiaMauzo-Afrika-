# Live Search & Security
- Verified paid users receive a private live search job.
- Server worker refreshes every 45–120 seconds.
- Results include price, location and seller.
- Payment webhook requires `X-NjiaMauzo-Webhook-Secret`.
- CSRF, PBKDF2, secure cookies, rate limits and security headers remain enabled.
- Client-side copy/context-menu/shortcut blocking is deterrence only; browsers cannot guarantee screenshot prevention.
- Use PostgreSQL for production persistence and keep secrets in Render Environment Variables.
- One Gunicorn worker is used so the in-process live-search worker does not duplicate work.
